package com.example.sonel.myapplication;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;

public class EditItemActivity extends AppCompatActivity {
private String item;
    private Button btn;
    private ArrayList<String> listarray;
    private int index;
    private ArrayAdapter<String> adapter;


    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        item = getIntent().getExtras().getString("item");
        editText = (EditText) findViewById(R.id.txtinput);
        editText.setText(item);

        btn = (Button) findViewById(R.id.btndone);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
      //listarray.set(index,textView.getText().toString());
               // adapter.notifyDataSetChanged();
              listarray.set(index,editText.getText().toString());
                adapter.notifyDataSetChanged();
            }
        });
    }
}
