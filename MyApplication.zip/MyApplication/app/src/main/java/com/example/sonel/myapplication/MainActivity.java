package com.example.sonel.myapplication;

import java.util.ArrayList;
import java.util.StringTokenizer;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DialogTitle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.content.Context;
import android.content.Intent;

import static android.R.attr.onClick;
import static android.R.id.list;
import static com.example.sonel.myapplication.R.id.parent;
import static com.example.sonel.myapplication.R.id.txtinput;


public class MainActivity extends AppCompatActivity {
    private Button bt;
    private ListView lv;
    private ArrayList<String> listarray;
   private ArrayAdapter<String> adapter;
    private EditText et;
    private  Context _context;
    private  String item;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt = (Button) findViewById(R.id.btnAdd);
        lv=(ListView)findViewById(R.id.list);
        et=(EditText) findViewById(R.id.txtItem) ;
        listarray=new ArrayList<String>();
        for (int i=0;i<1;i++){
            listarray.add("Task:"+i);
       }
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, listarray);
        lv.setAdapter(adapter);
        bt.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
              listarray.add(et.getText().toString());
                adapter.notifyDataSetChanged();
                lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id){
                       /* String value =(String) lv.getSelectedItem();
                        Intent a = new Intent(MainActivity.this,EditItemActivity.class);
                        a.putExtra("item",value);
                        startActivity(a);*/
                     //  String item =(String) lv.getSelectedItem();
                        Intent intent= new Intent(MainActivity.this,EditItemActivity.class);

                       intent.putExtra("item",adapter.getItem(position));
                        startActivity(intent);

                    }
                });

      }
            //public void onItemClick(AdapterView<?> parent,View view,int position,long id){
                //showInputBox(listarray.get(position),position);
           // }String EXTRA_RESPONSE;


        });


    }

public void showInputBox(String olditem,final int index){
    final Dialog dialog=new Dialog(MainActivity.this);
    dialog.setTitle("Input box");
    dialog.setContentView(R.layout.activity_edit_item);
    TextView txtMessage=(TextView)dialog.findViewById(R.id.txtmessage);
    txtMessage.setText("Update Item");
    txtMessage.setTextColor(Color.parseColor("#ff2222"));
    final EditText editText=(EditText)dialog.findViewById(R.id.txtinput);
    editText.setText(olditem);

}

}
